"use client";

import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import FloatingHearts from "@/components/FloatingHearts";
import Celebration from "@/components/Celebration";
import MusicToggle from "@/components/MusicToggle";
import WelcomeStep from "@/components/WelcomeStep";
import YesNoStep from "@/components/YesNoStep";
import OptionsStep from "@/components/OptionsStep";
import FinalStep from "@/components/FinalStep";
import {
  Answers,
  initialAnswers,
  whenOptions,
  whereOptions,
  foodOptions,
  vibeOptions,
} from "@/lib/types";

const TOTAL_STEPS = 6;

export default function Home() {
  const [step, setStep] = useState(1);
  const [answers, setAnswers] = useState<Answers>(initialAnswers);
  const [celebrating, setCelebrating] = useState(false);

  const goTo = (n: number) => setStep(n);

  const handleYes = () => {
    setCelebrating(true);
    goTo(3);
  };

  const handleFinish = () => {
    setCelebrating(true);
    goTo(7);
  };

  return (
    <main className="relative flex min-h-[100svh] w-full items-center justify-center px-4 py-16">
      <FloatingHearts />
      <Celebration
        active={celebrating}
        onDone={() => setCelebrating(false)}
        duration={2200}
      />

      <div className="relative z-10 flex w-full justify-center">
        <AnimatePresence mode="wait">
          {step === 1 && <WelcomeStep key="step-1" onNext={() => goTo(2)} />}

          {step === 2 && <YesNoStep key="step-2" onYes={handleYes} />}

          {step === 3 && (
            <OptionsStep
              key="step-3"
              step={3}
              total={TOTAL_STEPS}
              eyebrow="planning"
              title="When would you like to meet?"
              options={whenOptions}
              selected={answers.when}
              onSelect={(value) => setAnswers((a) => ({ ...a, when: value }))}
              onNext={() => goTo(4)}
              extra={
                answers.when === "custom" ? (
                  <input
                    type="date"
                    value={answers.customDate}
                    onChange={(e) =>
                      setAnswers((a) => ({ ...a, customDate: e.target.value }))
                    }
                    className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 font-body text-white outline-none transition focus:border-purple-300"
                  />
                ) : undefined
              }
            />
          )}

          {step === 4 && (
            <OptionsStep
              key="step-4"
              step={4}
              total={TOTAL_STEPS}
              eyebrow="location"
              title="Where should we meet? 📍"
              options={whereOptions}
              selected={answers.where}
              onSelect={(value) => setAnswers((a) => ({ ...a, where: value }))}
              onNext={() => goTo(5)}
            />
          )}

          {step === 5 && (
            <OptionsStep
              key="step-5"
              step={5}
              total={TOTAL_STEPS}
              eyebrow="treats"
              title="What would you like to eat? 🍰"
              options={foodOptions}
              selected={answers.food}
              onSelect={(value) => setAnswers((a) => ({ ...a, food: value }))}
              onNext={() => goTo(6)}
            />
          )}

          {step === 6 && (
            <OptionsStep
              key="step-6"
              step={6}
              total={TOTAL_STEPS}
              eyebrow="mood"
              title="What kind of vibe do you want? ❤️"
              options={vibeOptions}
              selected={answers.vibe}
              onSelect={(value) => setAnswers((a) => ({ ...a, vibe: value }))}
              onNext={handleFinish}
            />
          )}

          {step === 7 && <FinalStep key="step-7" answers={answers} />}
        </AnimatePresence>
      </div>

      <MusicToggle />
    </main>
  );
}
