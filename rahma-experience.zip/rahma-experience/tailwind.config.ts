import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        midnight: {
          950: "#0B0714",
          900: "#130B24",
          800: "#1D1132",
          700: "#2A1740",
        },
        pink: {
          300: "#FF9FC7",
          400: "#FF6FAE",
          500: "#F0428F",
          600: "#D62E77",
        },
        purple: {
          300: "#C6A5FF",
          400: "#A970FF",
          500: "#8C4CF0",
          600: "#6E32D1",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        script: ["var(--font-script)", "cursive"],
        body: ["var(--font-body)", "sans-serif"],
      },
      backgroundImage: {
        "app-gradient":
          "radial-gradient(circle at 15% 15%, rgba(140,76,240,0.35), transparent 45%), radial-gradient(circle at 85% 20%, rgba(240,66,143,0.3), transparent 45%), radial-gradient(circle at 50% 90%, rgba(140,76,240,0.25), transparent 50%), linear-gradient(180deg, #0B0714 0%, #130B24 50%, #1D1132 100%)",
        "card-gradient":
          "linear-gradient(135deg, rgba(240,66,143,0.16), rgba(140,76,240,0.16))",
        "button-gradient": "linear-gradient(120deg, #F0428F 0%, #8C4CF0 100%)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0) translateX(0) rotate(0deg)" },
          "50%": { transform: "translateY(-26px) translateX(10px) rotate(10deg)" },
        },
        glowPulse: {
          "0%, 100%": { opacity: "0.5", transform: "scale(1)" },
          "50%": { opacity: "0.9", transform: "scale(1.06)" },
        },
      },
      animation: {
        float: "float 9s ease-in-out infinite",
        glowPulse: "glowPulse 3s ease-in-out infinite",
      },
      boxShadow: {
        glow: "0 0 40px rgba(240,66,143,0.4)",
        glowPurple: "0 0 40px rgba(140,76,240,0.4)",
        glass: "0 8px 32px 0 rgba(0,0,0,0.45)",
      },
    },
  },
  plugins: [],
};
export default config;
