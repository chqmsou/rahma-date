"use client";

import type { ReactNode } from "react";
import StepContainer from "./StepContainer";
import QuestionCard from "./QuestionCard";
import AnimatedButton from "./AnimatedButton";
import ProgressBar from "./ProgressBar";
import type { Option } from "@/lib/types";

type Props = {
  step: number;
  total: number;
  eyebrow?: string;
  title: string;
  options: Option[];
  selected: string | null;
  onSelect: (value: string) => void;
  onNext: () => void;
  extra?: ReactNode;
};

export default function OptionsStep({
  step,
  total,
  eyebrow,
  title,
  options,
  selected,
  onSelect,
  onNext,
  extra,
}: Props) {
  return (
    <StepContainer className="flex flex-col items-center">
      <ProgressBar step={step} total={total} />

      <div className="mt-8 w-full">
        <QuestionCard eyebrow={eyebrow} title={title} />
      </div>

      <div className="mt-8 grid w-full grid-cols-1 gap-3 sm:grid-cols-2">
        {options.map((option) => (
          <AnimatedButton
            key={option.value}
            variant="option"
            selected={selected === option.value}
            onClick={() => onSelect(option.value)}
            ariaLabel={option.label}
          >
            <span className="text-2xl">{option.emoji}</span>
            <span className="text-white/90">{option.label}</span>
          </AnimatedButton>
        ))}
      </div>

      {extra && <div className="mt-5 w-full">{extra}</div>}

      <div className="mt-10">
        <AnimatedButton onClick={onNext} variant="primary" disabled={!selected}>
          NEXT →
        </AnimatedButton>
      </div>
    </StepContainer>
  );
}
