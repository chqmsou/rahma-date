"use client";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";

export default function MusicToggle() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = 0.35;
    }
  }, []);

  const toggle = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    try {
      if (playing) {
        audio.pause();
        setPlaying(false);
      } else {
        await audio.play();
        setPlaying(true);
      }
    } catch {
      setPlaying(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <audio ref={audioRef} loop preload="none">
        <source src="/audio/romantic-song.mp3" type="audio/mpeg" />
      </audio>
      <motion.button
        onClick={toggle}
        whileHover={{ scale: 1.08 }}
        whileTap={{ scale: 0.92 }}
        aria-label={playing ? "Pause music" : "Play music"}
        aria-pressed={playing}
        className="glass shadow-glass flex h-14 w-14 items-center justify-center rounded-full border border-white/15"
      >
        {playing ? (
          <span className="flex items-end gap-[3px]" aria-hidden="true">
            <motion.span
              className="w-[3px] rounded-full bg-purple-300"
              animate={{ height: [6, 16, 8, 14, 6] }}
              transition={{ duration: 1.2, repeat: Infinity }}
            />
            <motion.span
              className="w-[3px] rounded-full bg-pink-400"
              animate={{ height: [14, 6, 16, 8, 14] }}
              transition={{ duration: 1.2, repeat: Infinity }}
            />
            <motion.span
              className="w-[3px] rounded-full bg-purple-300"
              animate={{ height: [8, 14, 6, 16, 8] }}
              transition={{ duration: 1.2, repeat: Infinity }}
            />
          </span>
        ) : (
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true">
            <path
              d="M9 18V6l11-2v12"
              stroke="#C6A5FF"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="6" cy="18" r="3" stroke="#C6A5FF" strokeWidth="1.6" />
            <circle cx="17" cy="16" r="3" stroke="#C6A5FF" strokeWidth="1.6" />
          </svg>
        )}
      </motion.button>
    </div>
  );
}
