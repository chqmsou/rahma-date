"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import StepContainer from "./StepContainer";
import QuestionCard from "./QuestionCard";
import AnimatedButton from "./AnimatedButton";
import NoButton from "./NoButton";

type Props = {
  onYes: () => void;
};

export default function YesNoStep({ onYes }: Props) {
  const [confirmed, setConfirmed] = useState(false);

  const handleYes = () => {
    setConfirmed(true);
    setTimeout(onYes, 900);
  };

  return (
    <StepContainer className="flex flex-col items-center">
      <QuestionCard eyebrow="the question" title="Would you like to meet me? ❤️" />

      <div className="mt-10 flex flex-wrap items-center justify-center gap-6">
        <div className="relative">
          <AnimatedButton onClick={handleYes} variant="primary" disabled={confirmed}>
            YES ❤️
          </AnimatedButton>
          <AnimatePresence>
            {confirmed &&
              Array.from({ length: 10 }).map((_, i) => {
                const angle = (i / 10) * Math.PI * 2;
                const distance = 60 + Math.random() * 40;
                return (
                  <motion.svg
                    key={i}
                    className="pointer-events-none absolute left-1/2 top-1/2"
                    width={16}
                    height={16}
                    viewBox="0 0 24 24"
                    fill="none"
                    initial={{ x: 0, y: 0, opacity: 1, scale: 0 }}
                    animate={{
                      x: Math.cos(angle) * distance,
                      y: Math.sin(angle) * distance,
                      opacity: 0,
                      scale: 1.3,
                    }}
                    transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <path
                      d="M12 21s-7.5-4.6-10-9.2C.4 8.4 2.1 4.5 5.8 4A5.4 5.4 0 0 1 12 7.3 5.4 5.4 0 0 1 18.2 4c3.7.5 5.4 4.4 3.8 7.8C19.5 16.4 12 21 12 21z"
                      fill="#FF6FAE"
                    />
                  </motion.svg>
                );
              })}
          </AnimatePresence>
        </div>

        {!confirmed && <NoButton />}
      </div>
    </StepContainer>
  );
}
