"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

type Variant = "primary" | "secondary" | "option";

type Props = {
  children: ReactNode;
  onClick?: () => void;
  variant?: Variant;
  selected?: boolean;
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
  ariaLabel?: string;
};

const base =
  "font-body font-semibold transition-colors focus-visible:outline-none disabled:opacity-40 disabled:pointer-events-none";

const variantClasses: Record<Variant, string> = {
  primary:
    "rounded-full bg-button-gradient px-9 py-4 text-base text-white shadow-glow",
  secondary:
    "rounded-full border border-white/20 bg-white/5 px-9 py-4 text-base text-white/85 hover:border-purple-300/60",
  option:
    "flex w-full items-center gap-3 rounded-2xl border px-5 py-4 text-left text-base",
};

export default function AnimatedButton({
  children,
  onClick,
  variant = "primary",
  selected = false,
  disabled = false,
  type = "button",
  className = "",
  ariaLabel,
}: Props) {
  const optionSelectedClasses = selected
    ? "border-pink-400 bg-gradient-to-r from-pink-500/20 to-purple-500/20 shadow-glow"
    : "border-white/12 bg-white/5 hover:border-purple-300/50";

  return (
    <motion.button
      type={type}
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      aria-pressed={variant === "option" ? selected : undefined}
      whileHover={disabled ? undefined : { scale: 1.03, y: -2 }}
      whileTap={disabled ? undefined : { scale: 0.96 }}
      className={`${base} ${variantClasses[variant]} ${
        variant === "option" ? optionSelectedClasses : ""
      } ${className}`}
    >
      {children}
    </motion.button>
  );
}
