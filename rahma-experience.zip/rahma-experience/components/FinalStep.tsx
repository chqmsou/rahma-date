"use client";

import { motion } from "framer-motion";
import StepContainer from "./StepContainer";
import {
  Answers,
  whenOptions,
  whereOptions,
  foodOptions,
  vibeOptions,
  labelFor,
  emojiFor,
} from "@/lib/types";

type Props = {
  answers: Answers;
};

function SummaryRow({
  emoji,
  label,
  value,
  delay,
}: {
  emoji: string;
  label: string;
  value: string;
  delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-5 py-4"
    >
      <span className="flex items-center gap-3 font-body text-sm text-white/60">
        <span className="text-xl">{emoji}</span>
        {label}
      </span>
      <span className="font-body font-semibold text-white">{value}</span>
    </motion.div>
  );
}

export default function FinalStep({ answers }: Props) {
  const whenLabel =
    answers.when === "custom" && answers.customDate
      ? new Date(answers.customDate).toLocaleDateString("en-US", {
          weekday: "long",
          month: "long",
          day: "numeric",
        })
      : labelFor(whenOptions, answers.when);

  return (
    <StepContainer className="flex flex-col items-center">
      <motion.h1
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-4xl font-bold text-white sm:text-5xl"
      >
        Perfect <span className="gradient-text">❤️</span>
      </motion.h1>

      <p className="mt-3 font-body text-white/60">Here's everything, just as you planned it</p>

      <div className="mt-8 w-full space-y-3">
        <SummaryRow
          emoji={emojiFor(whenOptions, answers.when)}
          label="When"
          value={whenLabel || "—"}
          delay={0.2}
        />
        <SummaryRow
          emoji={emojiFor(whereOptions, answers.where)}
          label="Where"
          value={labelFor(whereOptions, answers.where) || "—"}
          delay={0.35}
        />
        <SummaryRow
          emoji={emojiFor(foodOptions, answers.food)}
          label="Food"
          value={labelFor(foodOptions, answers.food) || "—"}
          delay={0.5}
        />
        <SummaryRow
          emoji={emojiFor(vibeOptions, answers.vibe)}
          label="Mood"
          value={labelFor(vibeOptions, answers.vibe) || "—"}
          delay={0.65}
        />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.85, duration: 0.7 }}
        className="ornament mt-10 w-full max-w-xs"
      />

      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.7 }}
        className="mt-8 max-w-sm text-center font-display text-xl italic text-white/85"
      >
        I can't wait to see you. Every detail is set — the only thing missing
        now is you.
      </motion.p>
    </StepContainer>
  );
}
