"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

type Props = {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  className?: string;
};

export default function QuestionCard({ eyebrow, title, subtitle, className = "" }: Props) {
  return (
    <div className={`text-center ${className}`}>
      {eyebrow && (
        <motion.span
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.6 }}
          className="ornament mx-auto mb-5 max-w-[220px] font-body text-xs uppercase tracking-[0.3em] text-purple-300"
        >
          {eyebrow}
        </motion.span>
      )}
      <motion.h1
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="font-display text-3xl font-bold leading-tight text-white sm:text-4xl"
      >
        {title}
      </motion.h1>
      {subtitle && (
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mt-4 max-w-sm font-body text-base text-white/70 sm:text-lg"
        >
          {subtitle}
        </motion.p>
      )}
    </div>
  );
}
