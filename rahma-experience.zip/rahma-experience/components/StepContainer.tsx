"use client";

import { motion } from "framer-motion";
import type { ReactNode } from "react";

const variants = {
  initial: { opacity: 0, x: 80, scale: 0.97 },
  animate: { opacity: 1, x: 0, scale: 1 },
  exit: { opacity: 0, x: -80, scale: 0.97 },
};

type Props = {
  children: ReactNode;
  className?: string;
};

export default function StepContainer({ children, className = "" }: Props) {
  return (
    <motion.div
      variants={variants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      className={`glass shadow-glass relative w-full max-w-lg rounded-[2rem] border border-white/10 bg-card-gradient px-6 py-10 sm:px-10 sm:py-14 ${className}`}
    >
      {children}
    </motion.div>
  );
}
