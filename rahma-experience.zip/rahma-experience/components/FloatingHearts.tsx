"use client";

import { motion } from "framer-motion";
import { useMemo } from "react";

type Props = {
  count?: number;
  className?: string;
};

function HeartGlyph({ size }: { size: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path
        d="M12 21s-7.5-4.6-10-9.2C.4 8.4 2.1 4.5 5.8 4A5.4 5.4 0 0 1 12 7.3 5.4 5.4 0 0 1 18.2 4c3.7.5 5.4 4.4 3.8 7.8C19.5 16.4 12 21 12 21z"
        fill="url(#heartGrad)"
      />
      <defs>
        <linearGradient id="heartGrad" x1="0" y1="0" x2="24" y2="24">
          <stop offset="0%" stopColor="#FF6FAE" />
          <stop offset="100%" stopColor="#A970FF" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export default function FloatingHearts({ count = 20, className = "" }: Props) {
  const hearts = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        size: 8 + Math.random() * 22,
        duration: 9 + Math.random() * 14,
        delay: Math.random() * 10,
        opacity: 0.15 + Math.random() * 0.35,
      })),
    [count]
  );

  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none fixed inset-0 z-0 overflow-hidden ${className}`}
    >
      {hearts.map((h) => (
        <motion.div
          key={h.id}
          className="absolute bottom-0"
          style={{ left: `${h.left}%`, opacity: h.opacity }}
          initial={{ y: 40, opacity: 0 }}
          animate={{ y: "-120vh", opacity: [0, h.opacity, h.opacity, 0] }}
          transition={{
            duration: h.duration,
            delay: h.delay,
            repeat: Infinity,
            ease: "linear",
          }}
        >
          <HeartGlyph size={h.size} />
        </motion.div>
      ))}
    </div>
  );
}
