"use client";

import { motion } from "framer-motion";
import StepContainer from "./StepContainer";
import AnimatedButton from "./AnimatedButton";

type Props = {
  onNext: () => void;
};

export default function WelcomeStep({ onNext }: Props) {
  return (
    <StepContainer className="flex flex-col items-center">
      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="font-script text-6xl text-pink-300 sm:text-7xl"
      >
        Hey Rahma <span className="align-middle">❤️</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="mt-6 max-w-sm text-center font-body text-lg text-white/75"
      >
        I have something special to ask you...
      </motion.p>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="mt-10"
      >
        <AnimatedButton onClick={onNext} variant="primary">
          NEXT →
        </AnimatedButton>
      </motion.div>
    </StepContainer>
  );
}
