"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";

const teases = ["NO 😢", "Are you sure? 🥺", "Try again 😄", "Nice try 🙈", "So close! 😹"];

export default function NoButton() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [teaseIndex, setTeaseIndex] = useState(0);

  const runAway = () => {
    const container = containerRef.current;
    const range = container ? Math.min(container.clientWidth, 260) : 160;
    const nextX = (Math.random() - 0.5) * range;
    const nextY = (Math.random() - 0.5) * 90;
    setPos({ x: nextX, y: nextY });
    setTeaseIndex((i) => (i + 1) % teases.length);
  };

  return (
    <div
      ref={containerRef}
      className="relative flex h-24 w-full max-w-[220px] items-center justify-center"
    >
      <motion.button
        type="button"
        onHoverStart={runAway}
        onTouchStart={(e) => {
          e.preventDefault();
          runAway();
        }}
        onClick={runAway}
        animate={{ x: pos.x, y: pos.y }}
        transition={{ type: "spring", stiffness: 300, damping: 16 }}
        className="rounded-full border border-white/15 bg-white/5 px-8 py-4 font-body text-base font-medium text-white/70"
      >
        {teases[teaseIndex]}
      </motion.button>
    </div>
  );
}
