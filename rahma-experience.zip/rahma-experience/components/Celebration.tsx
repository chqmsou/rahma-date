"use client";

import { useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

type Props = {
  active: boolean;
  onDone?: () => void;
  duration?: number;
};

const confettiColors = ["#F0428F", "#8C4CF0", "#FF9FC7", "#C6A5FF", "#FF6FAE", "#FFFFFF"];

function ConfettiPiece({ index }: { index: number }) {
  const left = useMemo(() => Math.random() * 100, [index]);
  const delay = useMemo(() => Math.random() * 0.6, [index]);
  const duration = useMemo(() => 2.2 + Math.random() * 1.6, [index]);
  const rotate = useMemo(() => Math.random() * 360, [index]);
  const color = useMemo(
    () => confettiColors[Math.floor(Math.random() * confettiColors.length)],
    [index]
  );
  const width = useMemo(() => 6 + Math.random() * 6, [index]);
  const isCircle = index % 3 === 0;

  return (
    <motion.span
      className="absolute top-0"
      style={{
        left: `${left}%`,
        width,
        height: width * (isCircle ? 1 : 2.2),
        backgroundColor: color,
        borderRadius: isCircle ? "9999px" : "2px",
      }}
      initial={{ y: -20, opacity: 0, rotate: 0 }}
      animate={{ y: "110vh", opacity: [0, 1, 1, 0.8, 0], rotate }}
      transition={{ duration, delay, ease: "easeIn" }}
    />
  );
}

function HeartBurstPiece({ index, total }: { index: number; total: number }) {
  const angle = (index / total) * Math.PI * 2;
  const distance = 140 + Math.random() * 130;
  const x = Math.cos(angle) * distance;
  const y = Math.sin(angle) * distance;
  const size = 14 + Math.random() * 18;

  return (
    <motion.svg
      className="absolute left-1/2 top-1/2"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      initial={{ x: 0, y: 0, opacity: 1, scale: 0 }}
      animate={{ x, y, opacity: 0, scale: 1.2 }}
      transition={{ duration: 1.4 + Math.random() * 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <path
        d="M12 21s-7.5-4.6-10-9.2C.4 8.4 2.1 4.5 5.8 4A5.4 5.4 0 0 1 12 7.3 5.4 5.4 0 0 1 18.2 4c3.7.5 5.4 4.4 3.8 7.8C19.5 16.4 12 21 12 21z"
        fill="#F0428F"
      />
    </motion.svg>
  );
}

export default function Celebration({ active, onDone, duration = 2600 }: Props) {
  useEffect(() => {
    if (!active) return;
    const t = setTimeout(() => onDone?.(), duration);
    return () => clearTimeout(t);
  }, [active, onDone, duration]);

  return (
    <AnimatePresence>
      {active && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="pointer-events-none fixed inset-0 z-[80] overflow-hidden"
          aria-hidden="true"
        >
          {Array.from({ length: 60 }).map((_, i) => (
            <ConfettiPiece key={`c-${i}`} index={i} />
          ))}
          {Array.from({ length: 26 }).map((_, i) => (
            <HeartBurstPiece key={`h-${i}`} index={i} total={26} />
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
