"use client";

import { motion } from "framer-motion";

type Props = {
  step: number;
  total: number;
};

export default function ProgressBar({ step, total }: Props) {
  const percent = Math.min(100, Math.round((step / total) * 100));

  return (
    <div className="mx-auto w-full max-w-xs">
      <div className="mb-2 flex items-center justify-between font-body text-xs tracking-wide text-white/50">
        <span>
          Step {Math.min(step, total)} of {total}
        </span>
        <span>{percent}%</span>
      </div>
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
        <motion.div
          className="h-full rounded-full bg-button-gradient"
          initial={{ width: 0 }}
          animate={{ width: `${percent}%` }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>
    </div>
  );
}
