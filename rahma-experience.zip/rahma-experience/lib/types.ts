export type Option = {
  value: string;
  label: string;
  emoji: string;
};

export type Answers = {
  when: string | null;
  customDate: string;
  where: string | null;
  food: string | null;
  vibe: string | null;
};

export const initialAnswers: Answers = {
  when: null,
  customDate: "",
  where: null,
  food: null,
  vibe: null,
};

export const whenOptions: Option[] = [
  { value: "tomorrow", label: "Tomorrow", emoji: "🌅" },
  { value: "weekend", label: "This weekend", emoji: "🎉" },
  { value: "next-week", label: "Next week", emoji: "📅" },
  { value: "custom", label: "Pick a custom date", emoji: "🗓️" },
];

export const whereOptions: Option[] = [
  { value: "coffee", label: "Coffee shop", emoji: "☕" },
  { value: "restaurant", label: "Restaurant", emoji: "🍽️" },
  { value: "park", label: "Park walk", emoji: "🌳" },
  { value: "surprise", label: "Surprise place", emoji: "🎁" },
];

export const foodOptions: Option[] = [
  { value: "pizza", label: "Pizza", emoji: "🍕" },
  { value: "cake", label: "Cake and desserts", emoji: "🍰" },
  { value: "coffee-sweets", label: "Coffee and sweets", emoji: "☕" },
  { value: "icecream", label: "Ice cream", emoji: "🍦" },
  { value: "chocolate", label: "Chocolate", emoji: "🍫" },
];

export const vibeOptions: Option[] = [
  { value: "romantic", label: "Romantic", emoji: "💕" },
  { value: "funny", label: "Funny", emoji: "😄" },
  { value: "adventure", label: "Adventure", emoji: "🌄" },
  { value: "relaxing", label: "Relaxing", emoji: "🌙" },
];

export function labelFor(options: Option[], value: string | null): string {
  return options.find((o) => o.value === value)?.label ?? "";
}

export function emojiFor(options: Option[], value: string | null): string {
  return options.find((o) => o.value === value)?.emoji ?? "";
}
