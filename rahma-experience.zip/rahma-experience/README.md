# Rahma ❤️ — Interactive Dating Invitation

A step-by-step, dating-app-style invitation experience. Each question lives on its own animated screen — built with Next.js 15, React, TypeScript, Tailwind CSS, and Framer Motion.

## Getting started

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## The flow

1. **Welcome** — "Hey Rahma ❤️" / "I have something special to ask you..."
2. **The question** — "Would you like to meet me? ❤️" — YES triggers a heart-pulse animation and advances; NO dodges away on hover/tap/click.
3. **When** — Tomorrow / This weekend / Next week / a custom date picker.
4. **Where** — Coffee shop / Restaurant / Park walk / Surprise place.
5. **Food** — Pizza / Cake / Coffee & sweets / Ice cream / Chocolate.
6. **Vibe** — Romantic / Funny / Adventure / Relaxing.
7. **Final screen** — "Perfect ❤️" with a full summary, a heart explosion + confetti effect, and a closing message.

## Reusable components

- `StepContainer` — the glass card + slide/fade transition wrapper every screen sits inside
- `QuestionCard` — the title/subtitle heading block
- `AnimatedButton` — primary / secondary / option-card button variants
- `ProgressBar` — animated "Step X of Y" indicator
- `OptionsStep` — generic single-select question screen (used for steps 3–6)
- `Celebration` — the confetti + heart-burst overlay
- `NoButton` / `FloatingHearts` / `MusicToggle` — the playful and ambient extras

## Customize it

- **Copy & options**: edit `lib/types.ts` for all option labels/emojis, and each `components/*Step.tsx` file for wording.
- **Colors**: the dark pink/purple gradient palette lives in `tailwind.config.ts`.
- **Music**: drop an MP3 into `public/audio/romantic-song.mp3` — the toggle button already looks for it (fails silently if missing).
- **Answers**: currently the flow only lives in client state (nothing is sent anywhere). Wire `handleFinish` in `app/page.tsx` up to an API route or email service if you want the answers delivered somewhere.

## Tech

- Next.js 15 (App Router) + React 19 + TypeScript
- Tailwind CSS
- Framer Motion
- Mobile-first, dark gradient background, respects `prefers-reduced-motion`
